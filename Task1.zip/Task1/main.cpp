#include <iostream>
#include <vector>
#include <string>

using namespace std;

class TodoItem {
public:
    string task;
    bool completed;

    TodoItem(string t) {
        task = t;
        completed = false;
    }
};

class TodoList {
private:
    vector<TodoItem> tasks;

public:
    void addTask(string task) {
        tasks.emplace_back(task);
    }

    void markTaskComplete(int index) {
        if (index >= 0 && index < tasks.size()) {
            tasks[index].completed = true;
        }
    }

    void viewTasks() {
        cout << "Your current tasks:" << endl;
        for (int i = 0; i < tasks.size(); i++) {
            cout << "[" << (tasks[i].completed ? "X" : " ") << "] " << tasks[i].task << endl;
        }
    }
};


int main()
{
   TodoList todo;

    int choice;
    string task;
    int index;

    while (true) {
        cout << "1. Add task" << endl;
        cout << "2. Mark task complete" << endl;
        cout << "3. View tasks" << endl;
        cout << "4. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter task: ";
            cin.ignore();
            getline(cin, task);
            todo.addTask(task);
            cout << "Task added successfully!" << endl;
            break;
        case 2:
            todo.viewTasks();
            cout << "Enter the index of the task to mark as complete: ";
            cin >> index;
            todo.markTaskComplete(index - 1);
            cout << "Task marked as complete!" << endl;
            break;
        case 3:
            todo.viewTasks();
            break;
        case 4:
            cout << "Exiting..." << endl;
            return 0;
        default:
            cout << "Invalid choice. Please try again." << endl;
            break;
        }

        cout <<endl;
    }
}
